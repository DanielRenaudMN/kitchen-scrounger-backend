package com.scroungerbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScroungerbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
