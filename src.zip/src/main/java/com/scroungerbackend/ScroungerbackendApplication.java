package com.scroungerbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScroungerbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScroungerbackendApplication.class, args);
	}

}
