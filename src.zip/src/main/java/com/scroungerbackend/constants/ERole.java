package com.scroungerbackend.constants;

public enum ERole {
    ROLE_USER, ROLE_ADMIN
}
